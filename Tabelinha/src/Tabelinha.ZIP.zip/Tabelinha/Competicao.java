package Tabelinha;

public interface Competicao {
    //void iniciarPartida(TimePrincipal time1, TimePrincipal time2, int golsTime1, int golsTime2);
    void atualizarClassificacao(int golsFeitos, int golsSofridos);
}