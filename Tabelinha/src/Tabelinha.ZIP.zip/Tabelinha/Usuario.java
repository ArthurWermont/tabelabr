package Tabelinha;

public interface Usuario {
    public void addPeloUsuario();
}


